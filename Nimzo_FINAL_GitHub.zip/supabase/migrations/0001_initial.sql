create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text not null check (char_length(nickname) between 1 and 40),
  photo_url text,
  bio text default '',
  level integer not null default 1 check (level >= 1),
  vip_level integer not null default 0 check (vip_level >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 100),
  status text not null default 'live' check (status in ('live','ended','locked')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.room_members (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'audience' check (role in ('owner','moderator','speaker','audience')),
  muted boolean not null default false,
  joined_at timestamptz not null default now(),
  left_at timestamptz,
  primary key(room_id,user_id)
);
create table if not exists public.store_items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  price bigint not null default 0 check(price >= 0),
  asset_url text,
  active boolean not null default true,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create table if not exists public.inventory (
  user_id uuid not null references public.profiles(id) on delete cascade,
  item_id uuid not null references public.store_items(id) on delete cascade,
  quantity bigint not null default 1 check(quantity > 0),
  acquired_at timestamptz not null default now(),
  primary key(user_id,item_id)
);
create table if not exists public.gifts (
  id uuid primary key default gen_random_uuid(), name text not null, price bigint not null check(price>0), asset_url text, active boolean not null default true, metadata jsonb not null default '{}'::jsonb
);
create table if not exists public.gift_transactions (
  id uuid primary key default gen_random_uuid(), sender_id uuid not null references public.profiles(id), recipient_id uuid not null references public.profiles(id), room_id uuid references public.rooms(id), gift_id uuid not null references public.gifts(id), quantity integer not null check(quantity>0), created_at timestamptz not null default now()
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade, type text not null, title text not null, payload jsonb not null default '{}'::jsonb, read_at timestamptz, created_at timestamptz not null default now()
);
create table if not exists public.wallet_transactions (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade, amount bigint not null, kind text not null, reference_id uuid, metadata jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);
create index if not exists rooms_status_idx on public.rooms(status,created_at desc);
create index if not exists room_members_user_idx on public.room_members(user_id);
create index if not exists notifications_user_idx on public.notifications(user_id,created_at desc);
create index if not exists wallet_user_idx on public.wallet_transactions(user_id,created_at desc);

alter table public.profiles enable row level security;
alter table public.rooms enable row level security;
alter table public.room_members enable row level security;
alter table public.store_items enable row level security;
alter table public.inventory enable row level security;
alter table public.gifts enable row level security;
alter table public.gift_transactions enable row level security;
alter table public.notifications enable row level security;
alter table public.wallet_transactions enable row level security;

create policy "profiles readable" on public.profiles for select to authenticated using (true);
create policy "profile self insert" on public.profiles for insert to authenticated with check (auth.uid()=id);
create policy "profile self update" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);
create policy "live rooms readable" on public.rooms for select to authenticated using (status='live' or owner_id=auth.uid());
create policy "room owner insert" on public.rooms for insert to authenticated with check (owner_id=auth.uid());
create policy "room owner update" on public.rooms for update to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create policy "members readable" on public.room_members for select to authenticated using (true);
create policy "member self insert" on public.room_members for insert to authenticated with check (user_id=auth.uid());
create policy "member self update" on public.room_members for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "active store readable" on public.store_items for select to authenticated using (active=true);
create policy "own inventory readable" on public.inventory for select to authenticated using (user_id=auth.uid());
create policy "active gifts readable" on public.gifts for select to authenticated using (active=true);
create policy "gift tx participants readable" on public.gift_transactions for select to authenticated using (sender_id=auth.uid() or recipient_id=auth.uid());
create policy "own notifications" on public.notifications for select to authenticated using (user_id=auth.uid());
create policy "own notifications update" on public.notifications for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "own wallet readable" on public.wallet_transactions for select to authenticated using (user_id=auth.uid());

-- Sensitive balance/gift mutations must be implemented with SECURITY DEFINER functions after the real business rules are finalized.
