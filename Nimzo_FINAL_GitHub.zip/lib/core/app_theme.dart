import 'package:flutter/material.dart';

class NimzoTheme {
  static const teal = Color(0xFF16B5A4);
  static const ink = Color(0xFF1D2930);
  static const muted = Color(0xFF66757D);
  static const line = Color(0xFFE1E8EA);
  static ThemeData light() => ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: Colors.white,
    colorScheme: ColorScheme.fromSeed(seedColor: teal, brightness: Brightness.light),
    appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: ink, elevation: 0),
    cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(18)), side: BorderSide(color: line))),
  );
}
