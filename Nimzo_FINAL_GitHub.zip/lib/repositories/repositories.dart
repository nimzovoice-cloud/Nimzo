import '../models/models.dart';

abstract interface class RoomRepository { Future<List<VoiceRoom>> discover(); Future<VoiceRoom?> getById(String id); }
abstract interface class ProfileRepository { Future<Profile?> current(); }
abstract interface class StoreRepository { Future<List<StoreItem>> items(); }

class DemoRoomRepository implements RoomRepository {
  @override Future<List<VoiceRoom>> discover() async => const [
    VoiceRoom(id: 'room-1', title: 'Mr Adi • Chill & Chat', hostId: '192681', listeners: 128),
    VoiceRoom(id: 'room-2', title: 'Late Night Talks', hostId: '267191', listeners: 84),
    VoiceRoom(id: 'room-3', title: 'Friends Lounge', hostId: 'JUTT', listeners: 57),
    VoiceRoom(id: 'room-4', title: 'Music & Masti', hostId: 'P804', listeners: 41),
  ];
  @override Future<VoiceRoom?> getById(String id) async => (await discover()).firstWhere((r) => r.id == id, orElse: () => const VoiceRoom(id: '', title: '', hostId: ''));
}
class DemoProfileRepository implements ProfileRepository { @override Future<Profile?> current() async => const Profile(id: 'demo', nickname: 'MR ×Jutt'); }
class DemoStoreRepository implements StoreRepository { @override Future<List<StoreItem>> items() async => const [StoreItem(id:'f1',name:'Gold Frame',price:1200),StoreItem(id:'f2',name:'Royal Frame',price:2400),StoreItem(id:'f3',name:'Diamond Frame',price:5000),StoreItem(id:'f4',name:'Premium Frame',price:8000)]; }
