class Profile { final String id, nickname; final String? photoUrl; const Profile({required this.id, required this.nickname, this.photoUrl}); }
class VoiceRoom { final String id, title, hostId; final int listeners; const VoiceRoom({required this.id, required this.title, required this.hostId, this.listeners = 0}); }
class StoreItem { final String id, name; final int price; const StoreItem({required this.id, required this.name, required this.price}); }
class AppNotification { final String id, type, title; final bool read; const AppNotification({required this.id, required this.type, required this.title, this.read = false}); }
