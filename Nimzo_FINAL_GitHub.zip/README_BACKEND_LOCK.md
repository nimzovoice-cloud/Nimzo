# Nimzo Backend Lock — A to Z

This package contains the backend foundation intended to support the locked Nimzo voice-social UI.

## Included domains

- Authentication boundary via Supabase Auth
- Profiles, nickname, ID, level, VIP and verification
- Follow/friend relationships
- Voice rooms, members/seats and room chat
- Gifts, gift pricing, effects metadata and gift transactions
- Coins and diamonds wallet accounts + immutable ledger
- Recharge products and orders
- Withdrawal accounts and withdrawal requests
- Agencies, agency members, applications, commissions and settlements
- Store catalog and inventory
- VIP plans/subscriptions
- Experience/levels/achievements
- Notifications
- Moments/feed, likes and comments
- Direct conversations/messages
- Reports, bans and moderation records
- Admin/support role boundary
- Private storage buckets
- RLS policies
- Realtime tables

## Important production boundary

The repository cannot know or invent the real Supabase project credentials, payment provider credentials, or Vivox credentials. Those must be supplied through the real services/environment.

Money, coin/diamond balances, gift settlement, commission, salary, withdrawal and VIP entitlement must be performed by audited server-side RPCs/Edge Functions. The Flutter client must never be trusted to assign its own balance or premium entitlement.

The SQL migration deliberately does **not** contain fake credentials or fake payment/Vivox configuration.

## Agency economy

The schema supports:
- agency owner/manager/host membership
- host applications
- configurable commission rates
- gift-derived commission records
- period settlements
- salary/commission fields

Actual settlement calculations should be implemented server-side after the business rules are confirmed.

## UI contract

The locked original UI remains the presentation baseline. Backend work should connect data/services to that UI rather than redesign it.
