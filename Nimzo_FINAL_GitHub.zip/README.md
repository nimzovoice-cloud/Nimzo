# Nimzo Voice

Nimzo Voice is an Android-first social voice-room app.

## Important
The supplied repository audit found no existing Supabase backend or Vivox integration. This package therefore contains:
- the locked original white/light Nimzo UI direction
- Supabase-ready Flutter initialization
- typed models/repository boundaries
- reproducible SQL migrations with RLS
- demo UI data isolated from production backend data

No real Supabase URL/key or Vivox secret is included. Add your real project configuration before production use.

## Setup
1. Add `SUPABASE_URL` and `SUPABASE_ANON_KEY` through a secure build/config mechanism.
2. Run `flutter pub get`.
3. Apply `supabase/migrations/0001_initial.sql` to the real Supabase project.
4. Run `flutter analyze`.
5. Replace demo repositories with live implementations where marked.
